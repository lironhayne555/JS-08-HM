<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

__( 'Border', 'pojo' );
__( 'Pojo', 'pojo' );