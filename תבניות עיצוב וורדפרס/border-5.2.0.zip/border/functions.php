<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

include( 'core/bootstrap.php' );

// EOF