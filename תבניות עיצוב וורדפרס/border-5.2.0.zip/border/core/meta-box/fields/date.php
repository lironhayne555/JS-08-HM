<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Pojo_MetaBox_Field_Date extends Pojo_MetaBox_Field_Text {
	
	public $type = 'date';
}
