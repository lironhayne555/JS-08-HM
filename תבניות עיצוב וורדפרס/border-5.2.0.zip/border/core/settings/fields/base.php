<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

abstract class Pojo_Settings_Field_Base {
	
	public function render( $field ) {}
	
	public function __construct() {}
	
}
