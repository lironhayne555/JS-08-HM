<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

if ( ! defined( 'BFITHUMB_UPLOAD_DIR' ) )
	define( 'BFITHUMB_UPLOAD_DIR', 'thumbs' );