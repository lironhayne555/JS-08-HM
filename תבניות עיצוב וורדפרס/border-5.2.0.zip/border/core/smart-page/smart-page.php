<?php

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

include( 'api.php' );
// empty file for now..