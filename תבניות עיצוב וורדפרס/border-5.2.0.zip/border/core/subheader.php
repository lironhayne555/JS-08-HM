<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

// This is a deprecated file !
// What you see here it's just for fallback.

pojo_print_titlebar();